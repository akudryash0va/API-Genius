OVERVIEW

The "Genius" service is of an immence popularity among the alternative
music hosts such as soundcloud, apple music, spotify and vk.music due to
its functionality in terms of lyrics' provision. It allows the user to 
access the text of the desired songs. In order make the procedure more swift
and enlarge the scope of optionality within a minor framework, created in
python, the programme, enabling the search by either the name of the composition, 
or the artist, was created.

GOAL

The following project is aimed at the exploration of the Api interface,
provided by the developers' segment of "genius.com", via the creation of programme,
reflecting the "search" functionality and aggregating the summarised data, freely
available on the referenced website.

PROCEDURE

The app proceeds as following:
First of all, user is asked to enter the title of the track or the name of the artist.
Afterwards, the programm scopes tyhrough the genius website and produces a table of contents,
including ten top-results. Above the table the number of viewers of the artist's page is generated.
It refers to the primary result, as it is to be considered the most relevant.
Following this procedure, an interactive window is visualised, allowing user to authorize on the website,
or, in case of denial, choose between the two (or both) options, providing one with the direct links to
the artist's account.

RESULTS AND LIMITATIONS

"Genius" provides the developers with diverse optionality, however, it mostly refers to more complex
data integration and programme initialization. Therefore, in the following project, the usage of genius
app for api creation centered around the usage of token, as there are few particular requests, common for
"genius". All futher procedures included the usage of, mainly, Json, BeautifulSoup and Pandas. 

The scope of limitations refers, primarily, to the contents of the "genius" website, in case of 
information lack, for instance, album cover, the programme will not be able to provide user with a visualization, 
however, this could have been maintained by either addittion of code, accounting for exclusion, or improvised 
sample picture. Addittionally, the process of automatical authorisation via the current app is denied due to the 
policy of the website (because of this, users are forwarded towards the authorisation page in the browser). 
Steps for errors eradication were suggested at the end of the project, but are to be reconsidered in more details
in terms of the current problem as the solutions were extracted from the open sources.

Due to the lack of numerical values, produced by the app, the process of data visualization is 
constrained. A more detailed analysis of "Genius" API guidlenie is required to access more statistically valuable
features. On the whole, the programme summarises and reflect the optionality of the website and provides swift
acces to the desired data, therefore, representing a quick, "amateur" alternative. 


                                           "SPEECH OF MUSIC"


```python
        
#Import of the main libraries 

import selenium
import requests
from selenium import webdriver as wd
import os
from bs4 import BeautifulSoup
from IPython.core.display import HTML
import pandas as pd
#os.getcwd
```


```python
#  Introduction, welcoming the user and requiring 
#  the entry via the'input'. 
#  As it is assumed that the data entered will refer
#  to name of the song,there are no limitations included
#  on the type of the input as it is further transformed
#  to the string format.                                 

print("Hi! Here you will find the lyrics!")
user_choice = input("Enter the Title or the Artist: ")
user_choice = user_choice.title()
```

    Hi! Here you will find the lyrics!
    Enter the Title or the Artist: Scorpions



```python
# Identification of the base-variables

main_page = "http://api.genius.com" # Page, allowing parcing after API creation.
main_web = "http://genius.com"      # The main page of the website.
headers = {'Authorization': 'Bearer CxaF-mVwvPkpp91wg1QpB1nZu7TraGCQc5Rx4zbloerVYOrwPjkt7wHA3P4e99mY'}
                                    # Token of an API-client, required for futher requests. 
search = main_page + "/search"      # Base adress for further requests.
song = user_choice
params = {'q': song}                # Parameter, referring to the song, entered by user; for further requests.

output = requests.get(search, params=params, headers=headers) 



#views - Variable, acccounting for the provision of data on the page 
# views of an artist. Used oit of "for" cycle in order to avoid errors,
# when statistsics are lacking( for the first - top result(as it is
# considered to refer to the popular artist) the information is, generally,
# present). 
     

#Usage of requests module in order to identify the part of the
#code,referring to the search request, on the website.
                    
json_format = output.json()         
# Converting data to the Json format in order to further proceed to text.
#json_format
responses = json_format['response'] 
# As all the requests from Genius API are in Json format, the responses
#in accord to the searched information, are extracted as flollowing


fullinfo = responses['hits']
#fullinfo
#s = fullinfo[0]['result'] 

#views = s['stats']['pageviews']    #IMPORTANT: Might be absent for some artists -> hidden



L = []                               # Initialising an empty list for further Data Frame creation.

for i in fullinfo:  
                                     #Going through all the elements in the initial list as the data for
                                     #each particular output for the request is stored separably, and in 
                                     #accord to the index, can provide with the tags such as "full_title",
                                     #"stats", for instance, which bear the extracted information.

    
    x = fullinfo[fullinfo.index(i)]
    
    y = x['result']['path']          # y - Variable for the extraction of the path, used in link to the lyrics. 
    
    z = x['result']['full_title']    # z - Variable for the extraction of the song title.
    
    date = x['result']['release_date_for_display']
                                     # date - Variable for the extraction of the release date.
    
    pics = x['result']['song_art_image_url']
                                     #pics - Variable for the extraction of the album cover picture via link.
      
    
    def image(link):
        """ Method for conversion (of extracted "pics"-variable
            (link)) into the visualisible image.
            ARG: link - unobligatory
        """
        image_html =  f"<img src='{link}' width='500px'>"
        return image_html
        
                                
    
    
    path = str(y)
    web_path = main_web + path        # Settling down the form of the link to the lyrics.
    
    extraction = requests.get(web_path)
                                      # Extracting the raw data from the lyrics' page. 
    
    soup=BeautifulSoup(extraction.text, "html.parser")  
                                      # Using beautiful Soup to extract textual information from
                                      # the raw browser - html code for further search.
       

    lyrics = soup.find("div",{"class" : "Lyrics__Container-sc-1ynbvzw-6 jYfhrf"})
                                      # From the class, find the tag, preceding the lyrics.
   
        
    fulltext = lyrics.get_text(separator=". ") 
                                      # Separating the text by dot, as, initially, 
                                      # it does not split it correctly(after"<d>"").
 
   
    L.append([z, pics, date, fulltext, web_path ])
                                      # Adding the variables, described above to the 
                                      # predefined empty list "L".
  
        
    L_df = pd.DataFrame(L)    
                                      # Creatiing the data frame 
    
    L_df.columns = ["Title","Album Cover", "Release Date", "Lyrics", "Link for the Full Text"]
                                      # Providing the names to the columns of the dataframe
                                      #in accord to the functions of the variables
   
            
                  
                                
                                    
    L_df["Cover"] = L_df["Album Cover"].apply(image) 
    """ Applying the predefined "image" method for conersion of links
        to the jpg.
    """
        
#print("Page views: ",views)         #IMPORTANT: Might be absent for some artists -> hidden
                                     # Printing the number of views above the data frame.
    
                                     # HTML function allows to realise the previously used
                                     # "image" function in terms of the data frame.
HTML(L_df[["Title", "Cover","Lyrics","Release Date","Link for the Full Text"]].to_html(escape=False)) 
   
```




<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Title</th>
      <th>Cover</th>
      <th>Lyrics</th>
      <th>Release Date</th>
      <th>Link for the Full Text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Wind of Change by Scorpions</td>
      <td><img src='https://images.genius.com/9388a02ca0048a08361f9ba13f960728.600x600x1.jpg' width='500px'></td>
      <td>[Intro]. (Whistling). [Verse 1]. I follow the Moskva. Down to Gorky Park. Listening to the wind of change. An August summer night. Soldiers passing by. Listening to the wind of change. (Whistling). [Verse 2]. The world is closing in. And did you ever think. That we could be so close?. Like brothers. The future's in the air. I can feel it everywhere. Blowing with the wind of change. [Chorus]. Take me to the magic of the moment. On a glory night. Where the children of tomorrow dream away (dream away). In the wind of change. (mmmmmmm). [Verse 3]. Walking down the street. And distant memories. Are buried in the past forever. I follow the Moskva. And down to Gorky Park. Listening to the wind of change. [Chorus]. Take me (take me) to the magic of the moment. On a glory night (glory night). Where the children of tomorrow share their dreams (share their dreams). With you and me (you and me). Take me (take me) to the magic of the moment. On a glory night (a glory night). Where the children of tomorrow dream away (dream away). In the wind of change (wind of change). [Bridge]. The wind of change blows straight. Into the face of time. Like a storm wind that will ring. The freedom bell for peace of mind. Let your balalaika sing. What my guitar wants to sing (sing)</td>
      <td>November 25, 1990</td>
      <td>http://genius.com/Scorpions-wind-of-change-lyrics</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Still Loving You by Scorpions</td>
      <td><img src='https://images.genius.com/af91feb4596ea0f0d9081013565beeda.500x500x1.jpg' width='500px'></td>
      <td>[Verse 1]. Time, it needs time. To win back your love again. I will be there, I will be there. Love, only love. Can bring back your love someday. I will be there, I will be there. I'll fight, babe, I'll fight. To win back your love again. I will be there, I will be there. Love, only love. Can break down the wall someday. I will be there, I will be there. [Chorus]. If we'd go again. All the way from the start. I would try to change. The things that killed our love. Your pride has built a wall, so strong. That I can't get through. Is there really no chance. To start once again. I'm still loving you. [Verse 2]. Try, baby, try. To trust in my love again. I will be there, I will be there. Love, our love. Just shouldn't be thrown away. I will be there, I will be there. [Chorus]. If we'd go again. All the way from the start. I would try to change. The things that killed our love. Your pride has built a wall, so strong. That I can't get through. Is there really no chance. To start once again. If we'd go again. All the way from the start. I would try to change. The things that killed our love. Yes, I've hurt your pride, and I know. What you've been through. You should give me a chance. This can't be the end. I'm still loving you. I’m still loving you. I'm still loving you. I'm still loving you. I'm still loving you. I'm still loving you, I need your love. I'm still loving you</td>
      <td>March 27, 1984</td>
      <td>http://genius.com/Scorpions-still-loving-you-lyrics</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rock You Like a Hurricane by Scorpions</td>
      <td><img src='https://images.genius.com/911c47710250feb177e432521349aa87.450x450x1.jpg' width='500px'></td>
      <td>[Verse 1]. It's early morning, the sun comes out. Last night was shaking and pretty loud. My cat is purring, it scratches my skin. So what is wrong with another sin?. The bitch is hungry, she needs to tell. So give her inches and feed her well. More days to come, new places to go. I've got to leave, it's time for a show. [Chorus]. Here I am. Rock you like a hurricane. Here I am. Rock you like a hurricane. [Verse 2]. My body is burning, it starts to shout. Desire is coming, it breaks out loud. Lust is in cages till storm breaks loose. Just have to make it with someone I choose. The night is calling, I have to go. The wolf is hungry, he runs the show. He's licking his lips, he's ready to win. On the hunt tonight for love at first sting. [Chorus]. Here I am. Rock you like a hurricane. (Are you ready, babe?). Here I am. Rock you like a hurricane. Here I am. Rock you like a hurricane. (Come on, come on, babe!). Here I am. Rock you like a hurricane. [Post-Chorus]. Rock you like a hurricane!. [Guitar Solo]</td>
      <td>February 1984</td>
      <td>http://genius.com/Scorpions-rock-you-like-a-hurricane-lyrics</td>
    </tr>
    <tr>
      <th>3</th>
      <td>No One Like You by Scorpions</td>
      <td><img src='https://images.genius.com/2d7b19b2c4ac21123b7055b077142bea.600x600x1.jpg' width='500px'></td>
      <td>[Solo 1]. [Verse 1]. Girl, it's been a long time that we've been apart. Much too long for a man who needs love. I miss you since I've been away. Babe, it wasn't easy to leave you alone. It's getting harder each time that I go. If I had the choice, I would stay. [Chorus]. There's no one like you. I can't wait for the nights with you. I imagine the things we'll do. I just want to be loved by you. No one like you. I can't wait for the nights with you. I imagine the things we'll do. I just want to be loved by you. No one like you. [Verse 2]. Girl, there are really no words strong enough. To describe all my longing for love. I don't want my feelings restrained. Oh, babe, I just need you like never before. Just imagine you'd come through this door. You'd take all my sorrow away. [Chorus]. There's no one like you. I can't wait for the nights with you. I imagine the things we'll do. I just want to be loved by you. No one like you. I can't wait for the nights with you. I imagine the things we'll do. I just want to be loved by you. No one like you. [Solo 2]. [Chorus]. No one like you. I can't wait for the nights with you. I imagine the things we'll do. I just want to be loved by you. No one like you. I can't wait for the nights with you. I imagine the things we'll do. I just want to be loved by you</td>
      <td>March 21, 1982</td>
      <td>http://genius.com/Scorpions-no-one-like-you-lyrics</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Always Somewhere by Scorpions</td>
      <td><img src='https://images.genius.com/32ac6353dd041bcb708956a349be85c9.992x992x1.jpg' width='500px'></td>
      <td>[Verse 1]. Arrive at seven the place feels good. No time to call you today. Encores 'til eleven, then Chinese food. Back to the hotel again. [Verse 2]. I call your number; the line ain't free. I like to tell you come to me. A night without you seems like a lost dream. Love, I can't tell you how I feel. [Refrain]. Always somewhere. Miss you where I've been. I'll be back to love you again. Always somewhere. Miss you where I've been. I'll be back to love you again. [Verse 3]. Another morning another place. The only day off is far away. But every city has seen me in the end. And brings me to you again. [Refrain]. Always somewhere. Miss you where I've been. I'll be back to love you again. Always somewhere. Miss you where I've been. I'll be back to love you again</td>
      <td>January 15, 1979</td>
      <td>http://genius.com/Scorpions-always-somewhere-lyrics</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Send Me an Angel by Scorpions</td>
      <td><img src='https://images.genius.com/0a42cffed7b88335c4147620b5b8f93a.300x300x1.png' width='500px'></td>
      <td>[Verse 1]. Wise man said just walk this way. To the dawn of the light. The wind will blow into your face. As the years pass you by. Hear this voice from deep inside. It's the call of your heart. Close your eyes and you will find. Passage out of the dark. [Chorus]. Here I am. Will you send me an angel?. Here I am. In the land of the morning star!. [Verse 2]. Wise man said just find your place. In the eye of the storm. Seek the roses along the way. Just beware of the thorns. [Chorus]. Here I am. Will you send me an angel?. Here I am. In the land of the morning star!. [Verse 3]. Wise man said just raise your hand. And reach out for the spell. Find the door to the promised land. Just believe in yourself. Hear this voice from deep inside. It's the call of your heart. Close your eyes and you will find. The way out of the dark. [Outro]. Here I am. Will you send me an angel?. Here I am. In the land of the morning star!</td>
      <td>September 17, 1991</td>
      <td>http://genius.com/Scorpions-send-me-an-angel-lyrics</td>
    </tr>
    <tr>
      <th>6</th>
      <td>You and I by Scorpions</td>
      <td><img src='https://images.genius.com/8d94e0e7a48394138dcea95c7a6f6036.500x500x1.jpg' width='500px'></td>
      <td>[Chorus 1]. I lose control because of you babe. I lose control when you look at me like this. There's something in your eyes that is saying tonight. I'm not a child anymore, life has opened the door. To a new exciting life. [Chorus 2]. It's all written down in your lifelines. It's written down inside your heart. [Chorus 3]. You and i just have a dream. To find our love a place. Where we can hide away. You and I, we're just made. To love each other now. Forever and a day. [Chorus 1]. [Chorus 2]. [Chorus 3]. [Verse]. Time stands still. When days of innocence are falling for the night. I love you girl I always will. I swear i'm there for you until the day I'll die. [Chorus 3]</td>
      <td>May 21, 1996</td>
      <td>http://genius.com/Scorpions-you-and-i-lyrics</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Follow Your Heart by Scorpions</td>
      <td><img src='https://images.genius.com/ee85eb0943294ef41e7782ed13d23de5.600x600x1.png' width='500px'></td>
      <td>Have you ever climbed the mountain?. Have you ever crossed the sea?. Take a look around the corner. And listen to your heartbeat. Have you ever touched the rainbow. Take a ride in the ferris wheel. It takes one step to start a journey. It's up to you, to make it real. This is the time for yourself to be free. You gotta follow your heart. This is the time in your life and it's never too late. To see the light in the dark. You gotta follow your heart. Walking far away horizons. You will never walk alone. You'll be at home where your heart is. A million miles away from home. Show me the way, who knows the way. This is the only road to go. Life brings me down, it takes me up. And only, only heaven knows</td>
      <td>December 2, 2013</td>
      <td>http://genius.com/Scorpions-follow-your-heart-lyrics</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Holiday by Scorpions</td>
      <td><img src='https://images.genius.com/e1099bc25ec281bdc20613839315fe48.1000x1000x1.jpg' width='500px'></td>
      <td>Let me take you far away. You'd like a holiday. Let me take you far away. You'd like a holiday. Exchange the cold days for the sun. A good time and fun. Let me take you far away. You'd like a holiday. Let me take you far away. You'd like a holiday. Let me take you far away. You'd like a holiday. Exchange your troubles for some love. Wherever you are. Let me take you far away. You'd like a holiday. Longing for the sun here we come. To the island without name. Longing for the sun here we come. On the island many miles away from home. Here we come on the island without name. Longing for the sun here we come. To the island many miles away from home. Away from home. Away from home. Away from home. Away from home</td>
      <td>January 15, 1979</td>
      <td>http://genius.com/Scorpions-holiday-lyrics</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Humanity by Scorpions</td>
      <td><img src='https://images.genius.com/38b702ce392b795bf267d3846960e769.500x500x1.jpg' width='500px'></td>
      <td>[Verse 1]. Humanity, . auf wiedersehen. It's time to say goodbye, the party's over. As the laughter dies, an angel cries. Humanity, it's . au revoir.  to your insanity. You sold your soul to feed your vanity. Your fantasies and lies. [Chorus]. You're a drop in the rain. Just a number, not a name. And you don't see it. You don't believe it. At the end of the day. You're a needle in the hay. You signed and sealed it. And now you got to deal with it. Humanity, humanity. Goodbye. [Verse 2]. Be on your way, . adios amigo. There's a price to pay. For all the egotistic games you played. The world you made is gone. [Chorus]. You're a drop in the rain. Just a number, not a name. And you don't see it. You don't believe it. At the end of the day. You're a needle in the hay. You signed and sealed it. And now you got to deal with it. Humanity, humanity. Goodbye. [Bridge]. Run and hide there's fire in the sky. Stay inside. The water's gonna rise and pull you under. In your eyes I'm staring at the end of time. Nothing can change us. No one can save us from ourselves</td>
      <td>May 14, 2007</td>
      <td>http://genius.com/Scorpions-humanity-lyrics</td>
    </tr>
  </tbody>
</table>




```python

""" Importing prerequisites for the pop-up window creation """""

import tkinter as tk             
import tkinter.messagebox as mb
from tkinter import *


website = wd.Chrome("/Users/AnnaKudryashova/Desktop/Python/chromedriver — копия") 
                                    # Referring to the chromedriver via it location on the home computer.

def intro():
    """ Function for the creation of Tkinter - pop-up window. """
    
    answer=mb.askquestion(' ', "Do you want to authorize?")
                                     # Creating Tkinter with yes/no options to the predefined question. """
    
    if answer == 'no' :
        """ First "IF/ELIF" construction in accord to the answer in 
            the first pop-up window. 
        """
        ans_2=mb.askquestion(' ', "Are you sure that you want to use the app without authorisation?")
                                    # Creating another messagebox 
            
        if ans_2 == 'no': 
            """ Second "IF/ELIF" construction in accord to the answer in 
                the second pop-up window. 
            """
            mb.showinfo('Enter', "You will be automatically redirected to the authorization page")
                                    # Creating another messagebox.
            website.get("https://api.genius.com/oauth/authorize")
                                    # Redirecting to the autharisation page,
                                                    #(should have supported api client id).
            mb.showinfo('Authorisation', "Choose whether you want to sign up or sign in.")
                                    # Creating another messagebox.
            
        elif ans_2 == 'yes':        
            #base.destroy() = Tk()
            base = Tk()             # Creating another Tkinter with two options, defined further.
            base.title("Options")
            base.geometry("300x300")# Creating parameters of the pop-up window. 
            base.config(bg = "#CAC4B0") 
                                    # Setting the color of the pop-up window.
            
            
            def display(choice):
                """ Function for the creation of Tkinter - pop-up window
                    with embedded options.
                    Choice represents the option, chosen by the user.
                """
                choice = functions.get()
                x = (str(choice))   
                """ Third "IF/ELIF" construction in accord to the answer in 
                    the option menu. 
                """
                if x == "Find the lyrics":
                    for i in fullinfo:
                                    # Going through all of the extracted results via "each i" inde search.
                        x = fullinfo[fullinfo.index(i)]
                        
                        name = x['result']['full_title']
                                    # Extracting the name of the song.
                        LINK = x['result']['url']
                                    # Extracting the link to the lyrics on website.
                        print(name,"\n",LINK)
                        
                elif x == "Access information about the artist":
                    m = fullinfo[0]
                    mm =m['result']['primary_artist']['url']
                                   # Primary artist - referenced in case of the track, featuring several singers.
                    print(mm) 
                        
            options = ["Find the lyrics",
                       "Access information about the artist"]
            
            """ Set of options in the pop-up window """
                
            functions = StringVar() 
            """ Defining functions as the strinf variable in accord to the
                Tkinter documentation as it is the required element in the
                below function.
            """
            
            display = OptionMenu(base,
                                 functions,
                                 *options,
                                 command = display)
            """ Creating the option menu itself by attributing the variables,
                defined above and passing the function to it in order to get the choice
                of the user.
            """
            
            widen = len(max(options))#Unfortunately not working, should have resized the option window in
                                                                         #accord to the lengthest element.
            display.config(width = widen)
            display.grid()
            
             
            """ Creating the widget """
            display.pack(expand = True)
            display.mainloop()
            
            
            """ CONT'D, first "IF/ELIF" construction in accord to the answer in 
                the first pop-up window. 
            """
    elif answer == 'yes':
            
        mb.showinfo('Return', "You will be automatically redirected to the authorization page")
                                   # Creating another messagebox.
        website.get("https://api.genius.com/oauth/authorize")
                                   # Redirecting to the autharisation page,
        mb.showinfo('Authorisation', "Choose whether you want to sign up or sign in.")
                                   # Creating another messagebox.
        

intro()
```

    /var/folders/dx/cxfwdv9j77q221jt_m83thnh0000gp/T/ipykernel_37825/324543183.py:8: DeprecationWarning: executable_path has been deprecated, please pass in a Service object
      website = wd.Chrome("/Users/AnnaKudryashova/Desktop/Python/chromedriver — копия")






PREREQUISITES 

ПОИСК ПЕСНИ ПО НАЗВАНИЮ


```python
main_page = "http://api.genius.com"
headers = {'Authorization': 'Bearer CxaF-mVwvPkpp91wg1QpB1nZu7TraGCQc5Rx4zbloerVYOrwPjkt7wHA3P4e99mY'}
search = main_page + "/search"
song = "Buttechno"
params = {'q': song}
output = requests.get(search, params=params, headers=headers)
json_format = output.json()
json_format
#output_list = list(output)
#output_list

```




    {'meta': {'status': 200},
     'response': {'hits': [{'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 0,
         'api_path': '/songs/4276176',
         'artist_names': 'Buttechno',
         'full_title': 'Rz Bass by\xa0Buttechno',
         'header_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'header_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'id': 4276176,
         'lyrics_owner_id': 54639,
         'lyrics_state': 'complete',
         'path': '/Buttechno-rz-bass-lyrics',
         'pyongs_count': None,
         'release_date_for_display': 'January 28, 2019',
         'song_art_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'song_art_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'stats': {'unreviewed_annotations': 0, 'hot': False},
         'title': 'Rz Bass',
         'title_with_featured': 'Rz Bass',
         'url': 'https://genius.com/Buttechno-rz-bass-lyrics',
         'featured_artists': [],
         'primary_artist': {'api_path': '/artists/1715434',
          'header_image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'id': 1715434,
          'image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Buttechno',
          'url': 'https://genius.com/artists/Buttechno'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 0,
         'api_path': '/songs/4276175',
         'artist_names': 'Buttechno',
         'full_title': 'Orient Acd by\xa0Buttechno',
         'header_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'header_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'id': 4276175,
         'lyrics_owner_id': 54639,
         'lyrics_state': 'complete',
         'path': '/Buttechno-orient-acd-lyrics',
         'pyongs_count': None,
         'release_date_for_display': 'January 28, 2019',
         'song_art_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'song_art_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'stats': {'unreviewed_annotations': 0, 'hot': False},
         'title': 'Orient Acd',
         'title_with_featured': 'Orient Acd',
         'url': 'https://genius.com/Buttechno-orient-acd-lyrics',
         'featured_artists': [],
         'primary_artist': {'api_path': '/artists/1715434',
          'header_image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'id': 1715434,
          'image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Buttechno',
          'url': 'https://genius.com/artists/Buttechno'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 0,
         'api_path': '/songs/4276174',
         'artist_names': 'Buttechno',
         'full_title': 'Dub Hole Funkin by\xa0Buttechno',
         'header_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'header_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'id': 4276174,
         'lyrics_owner_id': 54639,
         'lyrics_state': 'complete',
         'path': '/Buttechno-dub-hole-funkin-lyrics',
         'pyongs_count': None,
         'release_date_for_display': 'January 28, 2019',
         'song_art_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'song_art_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'stats': {'unreviewed_annotations': 0, 'hot': False},
         'title': 'Dub Hole Funkin',
         'title_with_featured': 'Dub Hole Funkin',
         'url': 'https://genius.com/Buttechno-dub-hole-funkin-lyrics',
         'featured_artists': [],
         'primary_artist': {'api_path': '/artists/1715434',
          'header_image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'id': 1715434,
          'image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Buttechno',
          'url': 'https://genius.com/artists/Buttechno'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 0,
         'api_path': '/songs/4276168',
         'artist_names': 'Buttechno',
         'full_title': 'Dubber Funk by\xa0Buttechno',
         'header_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'header_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'id': 4276168,
         'lyrics_owner_id': 54639,
         'lyrics_state': 'complete',
         'path': '/Buttechno-dubber-funk-lyrics',
         'pyongs_count': None,
         'release_date_for_display': 'January 28, 2019',
         'song_art_image_thumbnail_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.300x300x1.jpg',
         'song_art_image_url': 'https://images.genius.com/afd48cd8180bcc985a1bcc8da76d39b9.1000x1000x1.jpg',
         'stats': {'unreviewed_annotations': 0, 'hot': False},
         'title': 'Dubber Funk',
         'title_with_featured': 'Dubber Funk',
         'url': 'https://genius.com/Buttechno-dubber-funk-lyrics',
         'featured_artists': [],
         'primary_artist': {'api_path': '/artists/1715434',
          'header_image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'id': 1715434,
          'image_url': 'https://images.genius.com/a12e268c3f7ff2fbdcc47f4a0e0d5ba3.666x666x1.jpg',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Buttechno',
          'url': 'https://genius.com/artists/Buttechno'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 12,
         'api_path': '/songs/209550',
         'artist_names': 'Tenacious D',
         'full_title': 'The Metal by\xa0Tenacious\xa0D',
         'header_image_thumbnail_url': 'https://images.genius.com/d8f635368930a709d26228636b9c86eb.300x300x1.jpg',
         'header_image_url': 'https://images.genius.com/d8f635368930a709d26228636b9c86eb.600x600x1.jpg',
         'id': 209550,
         'lyrics_owner_id': 253354,
         'lyrics_state': 'complete',
         'path': '/Tenacious-d-the-metal-lyrics',
         'pyongs_count': 18,
         'release_date_for_display': 'November 14, 2006',
         'song_art_image_thumbnail_url': 'https://images.genius.com/d8f635368930a709d26228636b9c86eb.300x300x1.jpg',
         'song_art_image_url': 'https://images.genius.com/d8f635368930a709d26228636b9c86eb.600x600x1.jpg',
         'stats': {'unreviewed_annotations': 4, 'hot': False, 'pageviews': 39729},
         'title': 'The Metal',
         'title_with_featured': 'The Metal',
         'url': 'https://genius.com/Tenacious-d-the-metal-lyrics',
         'featured_artists': [],
         'primary_artist': {'api_path': '/artists/19845',
          'header_image_url': 'https://images.genius.com/2f5e9dd0e80f2dec7e550ed866c22215.543x128x1.jpg',
          'id': 19845,
          'image_url': 'https://images.genius.com/7351f7df5e0279abba7b0c8db6e76534.421x421x1.jpg',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Tenacious D',
          'url': 'https://genius.com/artists/Tenacious-d'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 1,
         'api_path': '/songs/7257559',
         'artist_names': 'Philip Hicks (Ft. Jack Black & Kyle Gass)',
         'full_title': 'The Metal by\xa0Philip\xa0Hicks (Ft.\xa0Jack\xa0Black & Kyle\xa0Gass)',
         'header_image_thumbnail_url': 'https://images.genius.com/16b9814e70833b22ded9f1e0b8671680.210x210x1.png',
         'header_image_url': 'https://images.genius.com/16b9814e70833b22ded9f1e0b8671680.210x210x1.png',
         'id': 7257559,
         'lyrics_owner_id': 14932276,
         'lyrics_state': 'complete',
         'path': '/Philip-hicks-the-metal-lyrics',
         'pyongs_count': None,
         'release_date_for_display': 'October 3, 2021',
         'song_art_image_thumbnail_url': 'https://images.genius.com/16b9814e70833b22ded9f1e0b8671680.210x210x1.png',
         'song_art_image_url': 'https://images.genius.com/16b9814e70833b22ded9f1e0b8671680.210x210x1.png',
         'stats': {'unreviewed_annotations': 1, 'hot': False},
         'title': 'The Metal',
         'title_with_featured': 'The Metal (Ft.\xa0Jack\xa0Black & Kyle\xa0Gass)',
         'url': 'https://genius.com/Philip-hicks-the-metal-lyrics',
         'featured_artists': [{'api_path': '/artists/550060',
           'header_image_url': 'https://images.genius.com/2e0310ea3edddc2f29002abe161f9de9.300x300x1.jpg',
           'id': 550060,
           'image_url': 'https://images.genius.com/2e0310ea3edddc2f29002abe161f9de9.300x300x1.jpg',
           'is_meme_verified': False,
           'is_verified': False,
           'name': 'Kyle Gass',
           'url': 'https://genius.com/artists/Kyle-gass'},
          {'api_path': '/artists/81195',
           'header_image_url': 'https://images.genius.com/051123e82a38bc25b237f5d11087b022.720x720x1.jpg',
           'id': 81195,
           'image_url': 'https://images.genius.com/051123e82a38bc25b237f5d11087b022.720x720x1.jpg',
           'is_meme_verified': False,
           'is_verified': False,
           'name': 'Jack Black',
           'url': 'https://genius.com/artists/Jack-black'}],
         'primary_artist': {'api_path': '/artists/2902982',
          'header_image_url': 'https://images.genius.com/facb060fcf1567a394f5c1d28b95ef1b.144x108x1.png',
          'id': 2902982,
          'image_url': 'https://images.genius.com/d0299c7a2972d793497d93d943d3871e.616x616x1.png',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Philip Hicks',
          'url': 'https://genius.com/artists/Philip-hicks'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 2,
         'api_path': '/songs/7210220',
         'artist_names': "Kevin the Chronicler (Ft. Kevin's brother Jason)",
         'full_title': "Friend Like Dream [Dream SMP Parody Song] by\xa0Kevin\xa0the Chronicler (Ft.\xa0Kevin's\xa0brother Jason)",
         'header_image_thumbnail_url': 'https://images.genius.com/e23bfdd688ba487d1dcb013cb912add5.300x169x1.jpg',
         'header_image_url': 'https://images.genius.com/e23bfdd688ba487d1dcb013cb912add5.1000x563x1.jpg',
         'id': 7210220,
         'lyrics_owner_id': 14776380,
         'lyrics_state': 'complete',
         'path': '/Kevin-the-chronicler-friend-like-dream-dream-smp-parody-song-lyrics',
         'pyongs_count': None,
         'release_date_for_display': 'May 17, 2021',
         'song_art_image_thumbnail_url': 'https://images.genius.com/e23bfdd688ba487d1dcb013cb912add5.300x169x1.jpg',
         'song_art_image_url': 'https://images.genius.com/e23bfdd688ba487d1dcb013cb912add5.1000x563x1.jpg',
         'stats': {'unreviewed_annotations': 2, 'hot': False},
         'title': 'Friend Like Dream [Dream SMP Parody Song]',
         'title_with_featured': "Friend Like Dream [Dream SMP Parody Song] (Ft.\xa0Kevin's\xa0brother Jason)",
         'url': 'https://genius.com/Kevin-the-chronicler-friend-like-dream-dream-smp-parody-song-lyrics',
         'featured_artists': [{'api_path': '/artists/2885566',
           'header_image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
           'id': 2885566,
           'image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
           'is_meme_verified': False,
           'is_verified': False,
           'name': 'Kevin’s brother Jason',
           'url': 'https://genius.com/artists/Kevins-brother-jason'}],
         'primary_artist': {'api_path': '/artists/2885562',
          'header_image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
          'id': 2885562,
          'image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Kevin the Chronicler',
          'url': 'https://genius.com/artists/Kevin-the-chronicler'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 8,
         'api_path': '/songs/3125136',
         'artist_names': 'Jake Wintermute',
         'full_title': 'Course 1 P01 L00 Yogurt as Biotechnology by\xa0Jake\xa0Wintermute',
         'header_image_thumbnail_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'header_image_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'id': 3125136,
         'lyrics_owner_id': 4793266,
         'lyrics_state': 'complete',
         'path': '/Jake-wintermute-course-1-p01-l00-yogurt-as-biotechnology-annotated',
         'pyongs_count': None,
         'release_date_for_display': None,
         'song_art_image_thumbnail_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'song_art_image_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'stats': {'unreviewed_annotations': 8, 'hot': False},
         'title': 'Course 1 P01 L00 Yogurt as Biotechnology',
         'title_with_featured': 'Course 1 P01 L00 Yogurt as Biotechnology',
         'url': 'https://genius.com/Jake-wintermute-course-1-p01-l00-yogurt-as-biotechnology-annotated',
         'featured_artists': [],
         'primary_artist': {'api_path': '/artists/1158016',
          'header_image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
          'id': 1158016,
          'image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Jake Wintermute',
          'url': 'https://genius.com/artists/Jake-wintermute'}}},
       {'highlights': [],
        'index': 'song',
        'type': 'song',
        'result': {'annotation_count': 1,
         'api_path': '/songs/556465',
         'artist_names': 'Calestos Juma',
         'full_title': 'Preventing hunger: Biotechnology is key by\xa0Calestos\xa0Juma',
         'header_image_thumbnail_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'header_image_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'id': 556465,
         'lyrics_owner_id': 1251079,
         'lyrics_state': 'complete',
         'path': '/Calestos-juma-preventing-hunger-biotechnology-is-key-annotated',
         'pyongs_count': None,
         'release_date_for_display': None,
         'song_art_image_thumbnail_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'song_art_image_url': 'https://assets.genius.com/images/default_cover_image.png?1652889174',
         'stats': {'unreviewed_annotations': 0, 'hot': False},
         'title': 'Preventing hunger: Biotechnology is key',
         'title_with_featured': 'Preventing hunger: Biotechnology is key',
         'url': 'https://genius.com/Calestos-juma-preventing-hunger-biotechnology-is-key-annotated',
         'featured_artists': [],
         'primary_artist': {'api_path': '/artists/249465',
          'header_image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
          'id': 249465,
          'image_url': 'https://assets.genius.com/images/default_avatar_300.png?1652889174',
          'is_meme_verified': False,
          'is_verified': False,
          'name': 'Calestos Juma',
          'url': 'https://genius.com/artists/Calestos-juma'}}}]}}



AUTHORISATION WITH ERRORS("out of scope" and "ConnectionRefusedError: [Errno 61]")

website.get("https://api.genius.com/oauth/authorize")
website.get("https://api.genius.com/oauth/CxaF-mVwvPkpp91wg1QpB1nZu7TraGCQc5Rx4zbloerVYOrwPjkt7wHA3P4e99mY")
auery = {client_id= "n_52b7leUjz92Q4eiHP0LTGG-Ba-0_n5uYx5ixUim6NJlIHv7eTt5zUVtgsOrM6f",
#client_id
redirect_uri= "https://genius.com:"
#redirect_uri
scope="me" 
state=1
response_type= "code"

import os
os.getcwd

url = "https://genius.com/signup_or_login"
#headers = {'Authorization': 'Bearer CxaF-mVwvPkpp91wg1QpB1nZu7TraGCQc5Rx4zbloerVYOrwPjkt7wHA3P4e99mY'} 
private_data = {'email':'kudryash0va.anna@yandex.ru', "password": 'G8N_lyric$'}
response = requests.post(url, headers=headers, data=private_data)
response
website.get("https://api.genius.com/CxaF-mVwvPkpp91wg1QpB1nZu7TraGCQc5Rx4zbloerVYOrwPjkt7wHA3P4e99mY")



#<a href="/login" class="header-action header-action--sign_in facebox" rel="nofollow">Sign In</a>

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
import socket as s




options = webdriver.ChromeOptions()
options.add_argument("start-maximized");
options.add_argument("disable-infobars")
options.add_argument("--disable-extensions")
driver = website
driver.get("https://genius.com/signup_or_login")
WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//a[@track-element='user_login']"))).click()

try:
    webdriver.set_page_load_timeout(1)
    webdriver.get("http://www.engadget.com")
except TimeoutException as ex:
    isrunning = 0
    print("Exception has been thrown. " + str(ex))
    webdriver.close()
    
s = socket.socket()
host = '192.168.1.11'
port = 8880
s.connect((host, port))



#login = website.find_element_by_id("user_password") 
#login.send_keys("G8N_lyric$")
#<label for="user_login">Genius Nickname</label>
#<input class="required" id="user_login" name="user[login]" size="30" tabindex="1" title="Enter a nickname" type="text" />

#<label for="user_email">Email</label>
#<input class="required email" id="user_email" name="user[email]" size="30" tabindex="2" title="Enter your email address" type="text" />

#<label for="user_password">Password</label>
#<input class="required" id="user_password" name="user[password]" size="30" tabindex="3" title="Enter a password" type="password" />

#params_wall = {"client_id": "n_52b7leUjz92Q4eiHP0LTGG-Ba-0_n5uYx5ixUim6NJlIHv7eTt5zUVtgsOrM6f", #client_id
               #"redirect_uri": "https://genius.com:", 
               #"scope":"me",
               #"state":1,
               #"response_type": "code"}

#redir = "https://https://genius.com:/?code=code&state=1"
#redir
#req_wall = requests.get(login, params = params_wall)
#json_wall = req_wall.json()
#json_wall


#manage_annotation - another scope 

client_id = "n_52b7leUjz92Q4eiHP0LTGG-Ba-0_n5uYx5ixUim6NJlIHv7eTt5zUVtgsOrM6f", #client_id
redirect_uri = "https://genius.com:", 
scope = "me",
state = 1,
response_type= "code"

from getpass import getpass

website.get("https://api.genius.com/oauth/authorize") #choose whether want to sign up or login
website.get("https://genius.com/signup_or_login") #login was chosen
login = website.find_element_by_id("user_email") 
mail = "kudryash0va.anna@yandex.ru"
login.send_keys(mail)


password = getpass()
password_zone = website.find_element_by_id("user_password") 
login.send_keys(password)


```python

```


      File "/var/folders/dx/cxfwdv9j77q221jt_m83thnh0000gp/T/ipykernel_34906/1208955721.py", line 1
        python -m pydoc -p 311
                  ^
    SyntaxError: invalid syntax




```python

```
